// code points 0-31 and 127-255 are commented out to save memory
// font TinyUnicode is public domain, source: https://github.com/IT-Studio-Rech/bdf-fonts

/*
 * WBF (WLED Bitmap Font) Packed Fixed-Width Format
 * Header Layout (12 Bytes):
 * [0]   Magic 'W' (0x57)
 * [1]   Glyph height: 8
 * [2]   Fixed/max glyph width: 5
 * [3]   Spacing between chars: 1
 * [4]   Flags: 0x01 (0x01 = variable width)
 * [5]   First Char: 32
 * [6]   Last Char: 126
 * [7]   reserved: 0x00
 * [8-11] Unicode Offset (32-bit little-endian): 0x00000000
 * If variable width flag is set, header is followed by a width table of (Last Char - First Char + 1) bytes.
 * Packing: row-by-row, top first bitstream, MSB-first.
 */

/*
 * PACKING EXAMPLE: 4x6 Character '!'
 * -------------------------------------
 * VISUAL GRID (4x6):        BINARY ROWS
 * [Row 1]  . # . .  (2)        0010
 * [Row 2]  . # . .  (2)        0010
 * [Row 3]  . # . .  (2)        0010
 * [Row 4]  . . . .  (0)        0000
 * [Row 5]  . # . .  (2)        0010
 * [Row 6]  . . . .  (0)        0000
 * -------------------------------------
 * CONCATENATED STREAM:
 * Rows:   1 & 2 |  3 & 4 |  5 & 6
 * Bits: 00100010 00100000 00100000
 *       [Byte 1] [Byte 2] [Byte 3]
 * Final HEX for '!' = 0x22, 0x20, 0x20
 *
 * at the end of each glyph bitmap, padding bits are added if necessary to fill the last byte
 */

// Font: font_TinyUnicode_8px
// Height: 8, Max Width: 7, Spacing: 1
// Characters: 32-126 (95 glyphs)
// Unicode Offset: 0x00000000
// Variable Width: Yes

static const unsigned char font_TinyUnicode_8px[] PROGMEM = {
    0x57, 0x08, 0x07, 0x01, 0x01, 0x20, 0x7E, 0x00, 0x00, 0x00, 0x00, 0x00,  // Header: 'W', H, W, S, Flags, First, Last, Reserved, UnicodeOffset (32bit)

    // Width table
    0x07, 0x01, 0x03, 0x05, 0x04, 0x03, 0x05, 0x01, 0x02, 0x02, 0x03, 0x03, 0x02, 0x03, 0x01, 0x03,
    0x04, 0x02, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x01, 0x02, 0x02, 0x04, 0x02, 0x04,
    0x07, 0x04, 0x04, 0x03, 0x04, 0x03, 0x03, 0x04, 0x04, 0x03, 0x04, 0x04, 0x03, 0x05, 0x04, 0x04,
    0x04, 0x04, 0x04, 0x04, 0x03, 0x04, 0x04, 0x05, 0x04, 0x04, 0x03, 0x02, 0x03, 0x02, 0x03, 0x05,
    0x02, 0x04, 0x04, 0x03, 0x04, 0x04, 0x03, 0x04, 0x04, 0x01, 0x02, 0x04, 0x01, 0x05, 0x04, 0x04,
    0x04, 0x04, 0x03, 0x04, 0x03, 0x04, 0x04, 0x05, 0x03, 0x04, 0x04, 0x03, 0x01, 0x03, 0x05,

    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,     /* code=32, hex=0x20, ascii=" ", w=7 */
    0x74,                                         /* code=33, hex=0x21, ascii="!", w=1 */
    0xB4, 0x00, 0x00,                             /* code=34, hex=0x22, ascii=""", w=3 */
    0x01, 0x55, 0xF5, 0x50, 0x00,                 /* code=35, hex=0x23, ascii="#", w=5 */
    0x04, 0x7C, 0x3E, 0x20,                       /* code=36, hex=0x24, ascii="$", w=4 */
    0x14, 0xA9, 0x40,                             /* code=37, hex=0x25, ascii="%", w=3 */
    0x03, 0x20, 0xD9, 0x34, 0x00,                 /* code=38, hex=0x26, ascii="&", w=5 */
    0xC0,                                         /* code=39, hex=0x27, ascii="'", w=1 */
    0x6A, 0xA4,                                   /* code=40, hex=0x28, ascii="(", w=2 */
    0x95, 0x58,                                   /* code=41, hex=0x29, ascii=")", w=2 */
    0xAA, 0x80, 0x00,                             /* code=42, hex=0x2A, ascii="*", w=3 */
    0x01, 0x74, 0x00,                             /* code=43, hex=0x2B, ascii="+", w=3 */
    0x00, 0x18,                                   /* code=44, hex=0x2C, ascii=",", w=2 */
    0x00, 0x70, 0x00,                             /* code=45, hex=0x2D, ascii="-", w=3 */
    0x04,                                         /* code=46, hex=0x2E, ascii=".", w=1 */
    0x04, 0xA9, 0x00,                             /* code=47, hex=0x2F, ascii="/", w=3 */
    0x06, 0x99, 0x96, 0x00,                       /* code=48, hex=0x30, ascii="0", w=4 */
    0x1D, 0x50,                                   /* code=49, hex=0x31, ascii="1", w=2 */
    0x06, 0x92, 0x4F, 0x00,                       /* code=50, hex=0x32, ascii="2", w=4 */
    0x0E, 0x17, 0x1E, 0x00,                       /* code=51, hex=0x33, ascii="3", w=4 */
    0x02, 0x6A, 0xF2, 0x00,                       /* code=52, hex=0x34, ascii="4", w=4 */
    0x0F, 0x8E, 0x1E, 0x00,                       /* code=53, hex=0x35, ascii="5", w=4 */
    0x06, 0x8E, 0x96, 0x00,                       /* code=54, hex=0x36, ascii="6", w=4 */
    0x0F, 0x12, 0x44, 0x00,                       /* code=55, hex=0x37, ascii="7", w=4 */
    0x06, 0x96, 0x96, 0x00,                       /* code=56, hex=0x38, ascii="8", w=4 */
    0x06, 0x97, 0x16, 0x00,                       /* code=57, hex=0x39, ascii="9", w=4 */
    0x14,                                         /* code=58, hex=0x3A, ascii=":", w=1 */
    0x01, 0x18,                                   /* code=59, hex=0x3B, ascii=";", w=2 */
    0x06, 0x40,                                   /* code=60, hex=0x3C, ascii="<", w=2 */
    0x00, 0xF0, 0xF0, 0x00,                       /* code=61, hex=0x3D, ascii="=", w=4 */
    0x09, 0x80,                                   /* code=62, hex=0x3E, ascii=">", w=2 */
    0x0E, 0x16, 0x04, 0x00,                       /* code=63, hex=0x3F, ascii="?", w=4 */
    0x3C, 0x86, 0x6D, 0x59, 0xC8, 0x0F, 0x00,     /* code=64, hex=0x40, ascii="@", w=7 */
    0x06, 0x9F, 0x99, 0x00,                       /* code=65, hex=0x41, ascii="A", w=4 */
    0x0E, 0x9E, 0x9E, 0x00,                       /* code=66, hex=0x42, ascii="B", w=4 */
    0x0E, 0x48, 0xC0,                             /* code=67, hex=0x43, ascii="C", w=3 */
    0x0E, 0x99, 0x9E, 0x00,                       /* code=68, hex=0x44, ascii="D", w=4 */
    0x1E, 0x69, 0xC0,                             /* code=69, hex=0x45, ascii="E", w=3 */
    0x1E, 0x79, 0x00,                             /* code=70, hex=0x46, ascii="F", w=3 */
    0x07, 0x8B, 0x97, 0x00,                       /* code=71, hex=0x47, ascii="G", w=4 */
    0x09, 0x9F, 0x99, 0x00,                       /* code=72, hex=0x48, ascii="H", w=4 */
    0x1D, 0x25, 0xC0,                             /* code=73, hex=0x49, ascii="I", w=3 */
    0x07, 0x11, 0x96, 0x00,                       /* code=74, hex=0x4A, ascii="J", w=4 */
    0x09, 0xAC, 0xA9, 0x00,                       /* code=75, hex=0x4B, ascii="K", w=4 */
    0x12, 0x49, 0xC0,                             /* code=76, hex=0x4C, ascii="L", w=3 */
    0x04, 0x77, 0x58, 0xC4, 0x00,                 /* code=77, hex=0x4D, ascii="M", w=5 */
    0x09, 0xDB, 0x99, 0x00,                       /* code=78, hex=0x4E, ascii="N", w=4 */
    0x06, 0x99, 0x96, 0x00,                       /* code=79, hex=0x4F, ascii="O", w=4 */
    0x0E, 0x9E, 0x88, 0x00,                       /* code=80, hex=0x50, ascii="P", w=4 */
    0x06, 0x99, 0x96, 0x10,                       /* code=81, hex=0x51, ascii="Q", w=4 */
    0x0E, 0x99, 0xE9, 0x00,                       /* code=82, hex=0x52, ascii="R", w=4 */
    0x07, 0x86, 0x1E, 0x00,                       /* code=83, hex=0x53, ascii="S", w=4 */
    0x1D, 0x24, 0x80,                             /* code=84, hex=0x54, ascii="T", w=3 */
    0x09, 0x99, 0x96, 0x00,                       /* code=85, hex=0x55, ascii="U", w=4 */
    0x09, 0x9A, 0xA4, 0x00,                       /* code=86, hex=0x56, ascii="V", w=4 */
    0x04, 0x63, 0x5A, 0xA8, 0x00,                 /* code=87, hex=0x57, ascii="W", w=5 */
    0x09, 0x96, 0x99, 0x00,                       /* code=88, hex=0x58, ascii="X", w=4 */
    0x09, 0x97, 0x16, 0x00,                       /* code=89, hex=0x59, ascii="Y", w=4 */
    0x1C, 0xA9, 0xC0,                             /* code=90, hex=0x5A, ascii="Z", w=3 */
    0x3A, 0xAC,                                   /* code=91, hex=0x5B, ascii="[", w=2 */
    0x12, 0x22, 0x40,                             /* code=92, hex=0x5C, ascii="\", w=3 */
    0x35, 0x5C,                                   /* code=93, hex=0x5D, ascii="]", w=2 */
    0x0A, 0x80, 0x00,                             /* code=94, hex=0x5E, ascii="^", w=3 */
    0x00, 0x00, 0x00, 0x03, 0xE0,                 /* code=95, hex=0x5F, ascii="_", w=5 */
    0x24, 0x00,                                   /* code=96, hex=0x60, ascii="`", w=2 */
    0x00, 0x79, 0x97, 0x00,                       /* code=97, hex=0x61, ascii="a", w=4 */
    0x08, 0xE9, 0x9E, 0x00,                       /* code=98, hex=0x62, ascii="b", w=4 */
    0x01, 0xC8, 0xC0,                             /* code=99, hex=0x63, ascii="c", w=3 */
    0x01, 0x79, 0x97, 0x00,                       /* code=100, hex=0x64, ascii="d", w=4 */
    0x00, 0x6B, 0xC6, 0x00,                       /* code=101, hex=0x65, ascii="e", w=4 */
    0x0D, 0x74, 0x80,                             /* code=102, hex=0x66, ascii="f", w=3 */
    0x00, 0x79, 0x97, 0x16,                       /* code=103, hex=0x67, ascii="g", w=4 */
    0x08, 0xE9, 0x99, 0x00,                       /* code=104, hex=0x68, ascii="h", w=4 */
    0x5C,                                         /* code=105, hex=0x69, ascii="i", w=1 */
    0x11, 0x56,                                   /* code=106, hex=0x6A, ascii="j", w=2 */
    0x08, 0x9A, 0xE9, 0x00,                       /* code=107, hex=0x6B, ascii="k", w=4 */
    0x7C,                                         /* code=108, hex=0x6C, ascii="l", w=1 */
    0x00, 0x3D, 0x5A, 0xD4, 0x00,                 /* code=109, hex=0x6D, ascii="m", w=5 */
    0x00, 0xE9, 0x99, 0x00,                       /* code=110, hex=0x6E, ascii="n", w=4 */
    0x00, 0x69, 0x96, 0x00,                       /* code=111, hex=0x6F, ascii="o", w=4 */
    0x00, 0xE9, 0x9E, 0x88,                       /* code=112, hex=0x70, ascii="p", w=4 */
    0x00, 0x79, 0x97, 0x11,                       /* code=113, hex=0x71, ascii="q", w=4 */
    0x02, 0xE9, 0x00,                             /* code=114, hex=0x72, ascii="r", w=3 */
    0x00, 0x7C, 0x3E, 0x00,                       /* code=115, hex=0x73, ascii="s", w=4 */
    0x0B, 0xA4, 0xC0,                             /* code=116, hex=0x74, ascii="t", w=3 */
    0x00, 0x99, 0x97, 0x00,                       /* code=117, hex=0x75, ascii="u", w=4 */
    0x00, 0x99, 0xA4, 0x00,                       /* code=118, hex=0x76, ascii="v", w=4 */
    0x00, 0x23, 0x5A, 0xA8, 0x00,                 /* code=119, hex=0x77, ascii="w", w=5 */
    0x02, 0xA5, 0x40,                             /* code=120, hex=0x78, ascii="x", w=3 */
    0x00, 0x99, 0x97, 0x1E,                       /* code=121, hex=0x79, ascii="y", w=4 */
    0x00, 0xF2, 0x4F, 0x00,                       /* code=122, hex=0x7A, ascii="z", w=4 */
    0x69, 0x44, 0x98,                             /* code=123, hex=0x7B, ascii="{", w=3 */
    0x7C,                                         /* code=124, hex=0x7C, ascii="|", w=1 */
    0xC9, 0x14, 0xB0,                             /* code=125, hex=0x7D, ascii="}", w=3 */
    0x00, 0x13, 0x59, 0x00, 0x00                  /* code=126, hex=0x7E, ascii="~", w=5 */
};